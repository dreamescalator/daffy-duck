char *rxp_version_string = 
    "RXP 1.5.0 Copyright Richard Tobin, LTG, HCRC, University of Edinburgh";
